easyRTC Logs Folder
===================

This is the default location for easyRTC file logs.

Please see the documentation in the docs folder to read about configuration options.

Note: Logs can get fairly large. In linux environments, see the command logrotate which can be used to compress and store old logs.